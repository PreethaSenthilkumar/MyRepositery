﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataBinding
{
    class ProductStore
    {
        public Product GetProduct()
        {
            Product prod = new Product { ProductName = "Laptop", Category = "Computers" };
            return prod;
        }
    }
}
