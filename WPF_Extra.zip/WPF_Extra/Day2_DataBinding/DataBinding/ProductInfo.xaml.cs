﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataBinding
{
    /// <summary>
    /// Interaction logic for ProductInfo.xaml
    /// </summary>
    public partial class ProductInfo : Window
    {

        Product pr;
        ProductStore ps;
        public ProductInfo()
        {
            InitializeComponent();
            pr = new Product();
            ps = new ProductStore();
            pr = ps.GetProduct();
            this.DataContext = pr;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Product Name is " + pr.ProductName);

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            pr.ProductName = "TV";
            pr.Category = "Electronics";
        }

    }
}
