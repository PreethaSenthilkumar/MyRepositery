﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfDemo_ObjectBinding
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ProductDependency pd;
        //ProductDependency pd;
        ProductStore ps ;
        
        public MainWindow()
        {
            InitializeComponent();
            ps = new ProductStore();
            pd = new ProductDependency();
            pd = ps.GetProduct();//object initialized with properties
           this.DataContext = pd;// assigning the Source(in the form of object) to the toplevel element-Window
            
            //pd = ps.GetProducts();
            //this.DataContext = pd;
           
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(pd.ProductName ,pd.Category);

        }
        //on clicking this btn the source obj gets updated 
        //What happens to the Target?
        //Expected: Target also needs to be updated with the changes done in the source
        //Not possible with Normal Properties
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            //update the source object - pd
            pd.Category = "HouseHold";
            pd.ProductName = "Furniture";


        }
    }
}
