﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;//use this System.IO namespace for directory access

namespace DirectoryConsoleApplication
{
    /// <summary>
    /// Directory program
    /// 
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            string directoryName;

            //Recieving the directory name(path) from the user..
            Console.Write("Enter Directory Name with Full Path : ");
            directoryName = Console.ReadLine();

            DirectoryInfo directory = new DirectoryInfo(directoryName);

            if (directory.Exists)//Checking if the directory exists..
            {
                Console.WriteLine("Name : " + directory.Name);
                Console.WriteLine("Full Name : " + directory.FullName);
                Console.WriteLine("Creation Time : " + directory.CreationTime);
                Console.WriteLine("Parent : " + directory.Parent);
                Console.WriteLine("Root : " + directory.Root);

                //Files..
                FileInfo[] files = directory.GetFiles();//Returns a file from the current directory
                Console.WriteLine("\nNumber of Files in the directory : " + files.Length);//prints the number of files in the directory
                for (int i = 0; i < files.Length; i++)
                {
                    Console.WriteLine(files[i].Name);//The available file names printed on console.
                }

                //Sub-directories..
                DirectoryInfo[] subDir = directory.GetDirectories();//Returns the sub-directories of the current directory
                Console.WriteLine("Number of Sub Directories : " + subDir.Length);
                for (int i = 0; i < subDir.Length; i++)
                {
                    Console.WriteLine(subDir[i].Name);
                }

            }
            else
            {
                Console.WriteLine(directoryName + " does not exists");
            }

            Console.ReadKey();
        }
    }
}
