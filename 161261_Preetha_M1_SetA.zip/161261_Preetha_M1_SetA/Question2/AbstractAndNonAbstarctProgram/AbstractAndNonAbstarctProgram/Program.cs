﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractAndNonAbstarctProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            MathOp operation = new Addition();
            operation.Show();
            
            Subtraction s = new Subtraction();
            s.Show();

            Console.ReadKey();

        }
    }
}
