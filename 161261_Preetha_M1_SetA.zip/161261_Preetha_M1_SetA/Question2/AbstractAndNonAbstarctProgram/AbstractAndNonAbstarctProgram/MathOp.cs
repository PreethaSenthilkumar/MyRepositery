﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractAndNonAbstarctProgram
{
    public abstract class MathOp //abstract class Mathop
    {
        //public abstract int AddNumbers();
        //public abstract int SubNumbers();


        public int AddNumbers(int number1, int number2)
        {
            return number1 + number2;
        }
        public int SubNumbers(int number1, int number2)
        {
            return number1 - number2;
        }

        public virtual void Show()
        {
            Console.WriteLine("Add Method");
        }

        public virtual void Display()
        {
            Console.WriteLine("Subtract Method");
        }
    }
}
