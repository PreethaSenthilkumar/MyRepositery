﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Entity
{
    /// <summary>
    /// SUMMARY_INFO
    /// Student ID : Developers Student ID
    /// Student Name : Developers Student Name
    /// Description : This is an Entity Class for Student [PROJECT 1]
    /// Date of Modification : 8th Oct 2018
    /// </summary>

    [Serializable]//serializable keyword to be specified before the class to make it serializable..
    public class Student
    {
        //Specify the required properties for the Student Entity

        //Get or Set Student ID
        public int StudentID { get; set; }

        //Get or Set Student Name
        public string StudentName { get; set; }

        //Get or Set CourseName
        public string CourseName { get; set; }

        //Get or Set Grade
        public char Grade { get; set; }
    }
}
