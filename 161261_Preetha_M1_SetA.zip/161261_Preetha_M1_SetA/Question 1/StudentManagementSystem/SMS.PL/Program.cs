﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entity;       //Reference to Student Entity
using SMS.Exception;    //Reference to Student Exception
using SMS.BL;           //Reference to Student Layer

namespace SMS.PL
{
    class Program
    {
        //Method to add new Student
        public static void AddStudent()
        {
            try
            {
                Student std = new Student();
                Console.Write("Enter Student ID : ");
                std.StudentID = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Student Name : ");
                std.StudentName = Console.ReadLine();
     
                Console.Write("Enter Course Name : ");
                std.CourseName = Console.ReadLine();

                Console.Write("Enter Grade : ");
                std.Grade = Convert.ToChar(Console.ReadLine());

                bool isAdded = StudentValidations.AddStudent(std);

                if (isAdded)
                {
                    Console.WriteLine("Student details added successfully");
                }
                else
                    throw new StudentException("Student details not added");
            }
            catch (StudentException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

       

        
        
        public static void DisplayStudentDetails()
        {
            try
            {
                List<Student> studentList = StudentValidations.DisplayStudentDetails();

                if (studentList != null || studentList.Count > 0)
                {
                    Console.WriteLine("***********************************************************************************************************************");
                    Console.WriteLine("Student ID     Student Name  Courdename  Grade");
                    Console.WriteLine("***********************************************************************************************************************");
                    foreach (Student std in studentList)
                    {
                        Console.WriteLine(std.StudentID + "\t" + std.StudentName + "\t" + std.CourseName + "\t" + std.Grade);
                    }
                    Console.WriteLine("***********************************************************************************************************************");
                }
                else
                    throw new StudentException("Student Details not available");
            }
            catch (StudentException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SerializeStudent()
        {
            try
            {
                bool isSerialized = StudentValidations.SerializeStudent();

                if (isSerialized)
                    Console.WriteLine("Student Data is Serialized");
                else
                    throw new StudentException("Student Data is not Serialized");
            }
            catch (StudentException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeserializeStudent()
        {
            try
            {
                List<Student> empList = StudentValidations.DeserializeStudent();

                if (empList != null || empList.Count > 0)
                {
                    Console.WriteLine("***********************************************************************************************************************");
                    Console.WriteLine("Student ID    Student Name      Coursename    Grade");
                    Console.WriteLine("***********************************************************************************************************************");
                    foreach (Student emp in empList)
                    {
                        Console.WriteLine(emp.StudentID + "\t" + emp.StudentName + emp.CourseName + "\t" + emp.Grade);
                    }
                    Console.WriteLine("***********************************************************************************************************************");
                }
                else
                    throw new StudentException("Student Details not deserialized");
            }
            catch (StudentException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine("----------------------------");
            Console.WriteLine("MENU : ");
            Console.WriteLine("1. Add/Store Student");     
            Console.WriteLine("2. Display Student");
            Console.WriteLine("3. Serialize Student");
            Console.WriteLine("4. Deseialize Student");
            Console.WriteLine("5. Exit");
            Console.WriteLine("----------------------------");
        }
        static void Main(string[] args)
        {
            try
            {
                int choice;

                do
                {
                    PrintMenu();
                    Console.Write("Enter your choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:
                            AddStudent();
                            break;
                        
                        case 2:
                            DisplayStudentDetails();
                            break;
                        case 3:
                            SerializeStudent();
                            break;
                        case 4:
                            DeserializeStudent();
                            break;
                        case 5:
                            Environment.Exit(0);
                            break;
                        default:
                            Console.Write("Invalid Choice");
                            break;
                    }
                } while (choice != 5);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}
