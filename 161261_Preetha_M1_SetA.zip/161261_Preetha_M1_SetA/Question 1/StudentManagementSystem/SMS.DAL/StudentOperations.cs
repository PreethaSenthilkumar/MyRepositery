﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entity;       //Reference for Student Entity
using SMS.Exception;    //Reference for Student Exception
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace SMS.DAL
{
    /// <summary>
    /// SUMMARY_INFO
    /// Student ID : Developers Student ID
    /// Student Name : Developers Student Name
    /// Description : This class will provide the CRUD operations for the Student [PROJECT 2]
    /// DAL:DATA ACCESS LAYER: Pure DB logic...Validates and saves the data..
    /// Date of Modification : 8th Oct 2018
    /// </summary>

    public class StudentOperations
    {
        //Student Data storing and accessing through Collections via List...
        static List<Student> studentList = new List<Student>();

        //Try catch block handles the exceptions...

        //Method to store the data properly in a collection..
        public static bool AddStudent(Student std)
        {
            bool isAdded = false;

            try
            {
                //Storing student in the list
                studentList.Add(std); //Stores/adds the student details into the list..
                isAdded = true;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isAdded;
        }



        //Method to display Student information 
        public static List<Student> DisplayStudentDetails()
        {
            return studentList;
        }

        //Method to Serialize Student Data
        public static bool SerializeStudent()
        {
            bool isSerialized = false;

            try
            {
                //Writing the collection to a file
                //Creating object of stream
                FileStream fs = new FileStream("Student.txt", FileMode.Create, FileAccess.Write);
                //Creating BinaryFormatter object
                BinaryFormatter bin = new BinaryFormatter();
                //Serializing employee data in stream
                bin.Serialize(fs, studentList);
                fs.Close();

                //Reading the collection from the file and displaying the results               
                fs = new FileStream("Student.txt", FileMode.Open, FileAccess.Read);
                StreamReader sr = new StreamReader(fs);
                Console.WriteLine(sr.ReadToEnd());
                fs.Close();
                isSerialized = true;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isSerialized;
        }

        //Method to deserialize employee details
        public static List<Student> DeserializeStudent()
        {
            List<Student> student_deserialize_List = null;

            try
            {
                //Creating object of stream
                FileStream fs = new FileStream("Student.txt", FileMode.Open, FileAccess.Read);
                //Creating BinaryFormatter object
                BinaryFormatter bin = new BinaryFormatter();
                //Deserializing employee data from stream
                student_deserialize_List = (List<Student>)bin.Deserialize(fs);
                fs.Close();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return student_deserialize_List;
        }
    }
}
