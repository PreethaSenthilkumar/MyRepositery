﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Exception
{
    /// <summary>
    /// SUMMARY_INFO
    /// Student ID : Developers Student ID
    /// Student Name : Developers Student Name
    /// Description : This is an Exception Class for the Student [PROJECT 2]
    /// Date of Modification : 8th Oct 2018
    /// </summary>

    public class StudentException : ApplicationException //StudentException inherits the ApplicationException..
    {
        //Default Constructor
        public StudentException() : base() //default constructor --->parameterless
        { }


        //Parameterized constructor with message parameter
        public StudentException(string message) : base(message)
        { }

    }
}
