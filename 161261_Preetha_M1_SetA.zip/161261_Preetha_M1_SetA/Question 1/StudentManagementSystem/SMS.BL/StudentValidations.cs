﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using SMS.Entity;       //Reference to Student Entity
using SMS.Exception;    //Reference to Student Exception
using SMS.DAL;          //Reference to Student Data Access Layer

namespace SMS.BL
{
    /// <summary>
    /// SUMMARY_INFO
    /// Student ID : Developers Student ID
    /// Student Name : Developers Student Name
    /// Description : This class relates to business logic for the student [PROJECT 4]
    /// Date of Modification : 8th Oct 2018
    /// </summary>
    public class StudentValidations
    {
        //Method to validate employee details
        public static bool ValidateStudent(Student std)
        {
            bool isValidated = true;

            StringBuilder message = new StringBuilder();

            try
            {
                //Checking whether the specified conditions are satisfied..

                //Checking employee name
                if (std.StudentName == string.Empty)
                {
                    message.Append("StudentName should be provided\n");
                    isValidated = false;
                }
                else if (!Regex.IsMatch(std.StudentName, "[A-Z][a-z]{2,}"))
                {
                    message.Append("Employee Name should start with Capital Alphabet, it should have minimum 3 characters and only alphabets\n");
                    isValidated = false;
                }

                //Checking student id that it should be 6 digits
                if (std.StudentID < 100000 || std.StudentID > 999999)
                {
                    message.Append("StudentID should be 6 digits long\n");
                    isValidated = false;
                }

               

                //course name
                if(std.CourseName==string.Empty)
                {
                    message.Append("CourseName should be provided\n");
                    std.CourseName = "Computer";//assigned to Computer if not provided.
                    isValidated = false;
                }
             
                //Checking Grade
                if (std.Grade != 'A' && std.Grade != 'B' && std.Grade != 'C' && std.Grade != 'F')
                {
                    message.Append("The Grade should be A or B or C orF only\n");
                    isValidated = false;
                }

                if (isValidated == false)
                    throw new StudentException(message.ToString());
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isValidated;
        }

        //Method to add/store new student
        public static bool AddStudent(Student std)
        {
            bool isAdded = false;

            try
            {
                //Validating student details
                if (ValidateStudent(std))
                {
                    //Adding the Student by calling DAL Add method
                    isAdded = StudentOperations.AddStudent(std);
                }
                else
                    throw new StudentException("Please provide valid employee details");
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isAdded;
        }

       

        //Method to display all students
        public static List<Student> DisplayStudentDetails()
        {
            List<Student> studentList = null;

            try
            {
                //displaying students by calling DAL display method
               studentList = StudentOperations.DisplayStudentDetails();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studentList;
        }

        //Method to serialize student details
        public static bool SerializeStudent()
        {
            bool isSerialized = false;

            try
            {
                //Serializing by calling DAL serialize method
                isSerialized = StudentOperations.SerializeStudent();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isSerialized;
        }

        //Method to Deserialize Student
        public static List<Student> DeserializeStudent()
        {
            List<Student> stdList = null;

            try
            {
                //deserializing employee by calling DAL deserialize method
                stdList = StudentOperations.DeserializeStudent();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stdList;
        }
    }
}
