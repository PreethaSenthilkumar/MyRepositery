﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.Data.Objects;

//references>Add reference --System.Data.Entity
namespace DemoCruDOpertions
{
    class Program
    {
        static void Main(string[] args)
        {
           NorthwindEntities db = new NorthwindEntities();

            //Customer cust = new Customer();

            //cust.CompanyName="Capgemini";
            //cust.CustomerID = "Abc";
            //db.Customers.Add(cust);
            //db.SaveChanges();

            modifycust(db);

        }

        private static void modifycust(NorthwindEntities context )
        {
            try
            {
                Customer c = context.Customers.First(i => i.CustomerID == "ABC");
                //context.Customers.Attach(c);
               
                //uncomment for delete 
                //context.Customers.Remove (c);
                c.CompanyName = "IGATE";
                context.SaveChanges();
                //Console.WriteLine("Record modified");
                //Console.WriteLine("Record deleted");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.InnerException);
            }
        }

      
    }
}
