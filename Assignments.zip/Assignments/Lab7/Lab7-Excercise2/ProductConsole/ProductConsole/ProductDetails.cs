﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductConsole
{
    class productDetails
    {
        public int ProductNo { get; set; }
        public string Name { get; set; }
        public int Rate { get; set; }
        public int Stock { get; set; }

        public static void AddProduct(ref ArrayList ProductsList)
        {


            productDetails MyProduct = new productDetails();

            Console.WriteLine("Enter the Product No. : ");
            MyProduct.ProductNo = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the Product Name : ");
            MyProduct.Name = Console.ReadLine();

            Console.WriteLine("Enter the Product Rate : ");
            MyProduct.Rate = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the Product Stock remaining : ");
            MyProduct.Stock = Convert.ToInt32(Console.ReadLine());

            ProductsList.Add(MyProduct);



        }
        //delete
        public static void DeleteProduct(ref ArrayList ProductList)
        {
            int ProductNo = Convert.ToInt32(Console.ReadLine());
            bool ProdDeleted = false;

            foreach (productDetails product in ProductList)
            {
                if (product.ProductNo == ProductNo)
                {
                    ProductList.Remove(product);
                    ProdDeleted = true;
                    break;
                }

            }
            if (ProdDeleted == true)
                Console.WriteLine("Product Deleted");
            else
                Console.WriteLine("No Product Found For ID " + ProductNo);
        }
        //search
        public static void SearchProduct(ref ArrayList ProductList)
        {
            Console.WriteLine("Enter Product ID : ");
            int ProductId = Convert.ToInt32(Console.ReadLine());
            bool Productfound = false;
            foreach (productDetails product in ProductList)
            {
                if (product.ProductNo == ProductId)
                {
                    Console.WriteLine("\nProduct No. : " + product.ProductNo);
                    Console.WriteLine("Product Name : " + product.Name);
                    Console.WriteLine("Product Rate :" + product.Rate);
                    Console.WriteLine("Product Stock : " + product.Stock);
                    Productfound = true;
                }
            }
            if (Productfound == false)
                Console.WriteLine("No Product Found For ID : " + ProductId);
        }
        //sort
        public static void SortProduct(ref ArrayList ProductList)
        {

            //ProductList.Sort(ProductList, delegate (productDetails x, productDetails y)
            //{
            //    return x.ProductNo.CompareTo(y.ProductNo);
            //});
        }
        public static void Display(ref ArrayList ProductList)
        {
            foreach (productDetails product in ProductList)
            {
                Console.WriteLine("\nProduct No. : " + product.ProductNo);
                Console.WriteLine("Product Name : " + product.Name);
                Console.WriteLine("Product Rate :" + product.Rate);
                Console.WriteLine("Product Stock : " + product.Stock);
            }
        }
    }

}