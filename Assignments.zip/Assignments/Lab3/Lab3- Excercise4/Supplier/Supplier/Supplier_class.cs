﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supplier
{
    //Create suplier class..
    public class Supplier_class
    {
        //declare supplier  details..
        private int supplierID;
        private string supplierName;
        private string city;
        private string phoneNo;
        private string email;

        //Scanning function
        public void AcceptDetails()
        {
            Console.WriteLine("Enter Supplier ID: ");
            supplierID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Supplier Name: ");
            supplierName = Console.ReadLine();
            Console.WriteLine("Enter Supplier City: ");
            city = Console.ReadLine();
            Console.WriteLine("Enter Supplier Phone No.: ");
            phoneNo = Console.ReadLine();
            Console.WriteLine("Enter Supplier EmailID: ");
            email = Console.ReadLine();
        }

        //Displaying function
        public void DisplayDetails()
        {
            Console.WriteLine("Supplier ID: " + supplierID);
            Console.WriteLine("Supplier Name: " + supplierName);
            Console.WriteLine("Supplier City: " + city);
            Console.WriteLine("Supplier PhoneNo: " + phoneNo);
            Console.WriteLine("Supplier EmailID: " + email);

        }
    }
}