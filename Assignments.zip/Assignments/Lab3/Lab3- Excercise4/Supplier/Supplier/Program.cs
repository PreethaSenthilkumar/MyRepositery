﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supplier
{
    class SupplierTest : Supplier_class  //  SupplierTest  inherits Supplier_class
    {
        static void Main(string[] args)
        {
            //create an object for the suppier_class
            Supplier_class s1 = new Supplier_class();
            s1.AcceptDetails();
            s1.DisplayDetails();

            Console.ReadKey();
        }
    }
}