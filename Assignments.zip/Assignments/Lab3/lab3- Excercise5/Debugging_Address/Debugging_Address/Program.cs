﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Debugging_Address
{
    public class Address
    {
       //address property..
        public string Line1 { get; set; }
        public string Line2 { get; set; }
        public int Pincode { get; set; }
    }

    public class Person
    {
        //person_Details property
        public int Id { get; set; }
        public string Name { get; set; }
        public char Gender { get; set; }

        public virtual void Print()
        {
            Console.WriteLine("{0}\n{1}\n{2}\n"
                , Id, Name, Gender);
        }
    }

    public class Employee : Person //Emplyee inherits from Person class
    {
        Address HomeAddress;
        Address OfficeAddress;

        public void SetData()
        {
            Console.WriteLine("Enter Id");
            Id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Name");
            Name = Console.ReadLine();
            Console.WriteLine("Enter Gender");
            Gender = char.Parse(Console.ReadLine());

            Console.WriteLine("Enter Home Address Line1");
            // here
            HomeAddress = new Address();
            HomeAddress.Line1 = Console.ReadLine();
            Console.WriteLine("Enter Home Address Line2");
            HomeAddress.Line2 = Console.ReadLine();
            Console.WriteLine("Enter Home Address Pincode");
            HomeAddress.Pincode = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Office Address Line1");
            // here
            OfficeAddress = new Address();
            OfficeAddress.Line1 = Console.ReadLine();
            Console.WriteLine("Enter Home Office Line2");
            OfficeAddress.Line2 = Console.ReadLine();
            Console.WriteLine("Enter Home Office Pincode");
            OfficeAddress.Pincode = int.Parse(Console.ReadLine());
        }

        public override void Print()
        {
            Console.WriteLine("Id:{0}\nName:{1}\nGender:{2}\nHome Address:\n{3}\n{4}\n{5}\nOffice Address:\n{6}\n{7}\n{8}"
                , Id, Name, Gender,
                HomeAddress.Line1, HomeAddress.Line2, HomeAddress.Pincode,
                OfficeAddress.Line1, OfficeAddress.Line2, OfficeAddress.Pincode);
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
            //handle the exceptions with try catch block..
            try
            {
                Employee emp = new Employee();
                emp.SetData();
                Console.WriteLine();
                emp.Print();
            }
            catch (NullReferenceException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
    }

}