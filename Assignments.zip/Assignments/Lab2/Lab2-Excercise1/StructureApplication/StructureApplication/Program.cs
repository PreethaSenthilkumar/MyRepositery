﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructureApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Struct_Example st = new Struct_Example();//structure object..

            int number;
   
           for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("Enter the number : ");
                number=Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the type of calculation you prefer..");
                Console.WriteLine("1.Square operation \n 2.Cube Operation \n");
                string type=Console.ReadLine();

                if(type=="Square")
                {
                    int sq = st.square_function(number);
                    Console.WriteLine("The Square Value is : "+sq);
                }
                else if(type=="Cube")
                {
                    int cu = st.cube_function(number);
                        Console.WriteLine("The Square Value is : " + cu);
                    }
                }
            }
    }
   
}

