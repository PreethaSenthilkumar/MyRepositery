﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructureApplication
{
    public struct Struct_Example
    {
        public int number; //number variable
        
        public Struct_Example(int number) //instance constructor
        {
            this.number=number;
        }

        public int X //method property
        {
            get { return number; }
            set { int number = value; }
        }

        //Square function
        public int square_function(int number)
        {
            return  (number * number);
        }

        //Cube function
        public int cube_function(int number)
        {
            return (number * number * number);
        }
    }
}
