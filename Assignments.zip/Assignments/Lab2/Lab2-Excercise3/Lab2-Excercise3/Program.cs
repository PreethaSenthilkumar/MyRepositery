﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_Excercise3
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declare the single-dimensional array
            string[] str_arr = new string[4];

            //scan the cities via for loop
            Console.WriteLine("Enter the cities\n");
            for (int i = 0; i < str_arr.Length; i++)
            {
                str_arr[i]=Console.ReadLine();
            }

            //print the cities via foreach loop
            Console.WriteLine("\nThe cities are  \n");
            foreach (string item in str_arr)
            {
                Console.WriteLine(item);
            }
            Console.ReadKey();
        }
    }
}
