﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductDemoSample
{
   class ProductDemo
    {
        object ProductID;
        object ProductName;
        object ProductPrice;
        object ProductQuantity;

       //object amount_payable;
        static void Main(string[] args)
        {
            ProductDemo pd = new ProductDemo();
            double amount_payable;
            //boxing
            Console.WriteLine("Enter the id of the product : ");
            pd.ProductID=Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the name of the product : ");
             pd.ProductName= Console.ReadLine();

            Console.WriteLine("Enter price : ");
            pd.ProductPrice = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter quantity : ");
            pd.ProductQuantity= Convert.ToInt32(Console.ReadLine());

            //unboxing...
            Console.WriteLine("\nProduct Details:");
            Console.WriteLine("Product ID : "+(int)pd.ProductID);
            Console.WriteLine("Product Name :"+(string)pd.ProductName);
            Console.WriteLine("Price : "+(int)pd.ProductPrice);
            Console.WriteLine("Quantity : "+(int)pd.ProductQuantity);
            amount_payable=(Convert.ToDouble(pd.ProductPrice)) * (Convert.ToDouble(pd.ProductQuantity));
            Console.WriteLine("Amount payable " + amount_payable);
            Console.ReadKey();
        }
    }
}
