﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoDimensionalArray
{
    class Program
    {
        public static void Main(string[] args)
        {
            int[,] arr = new int[5,6]; //2-Dimensional Array Declaration...


            //Array elements scanned from console..
            Console.WriteLine("Enter the Elements of the matrix : ");

            for (int i = 0; i < arr.GetLength(0); i++)
            {
                for (int j = 0; j < arr.GetLength(1); j++)
                {
                    arr[i,j]=Convert.ToInt32(Console.ReadLine());
                }
            }


            //ScannedArray printed
            Console.WriteLine("The Elements of the matrix  : ");

            for (int i = 0; i < arr.GetLength(0); i++)
            {
                for (int j = 0; j < arr.GetLength(1); j++)
                {
                     Console.Write(arr[i,j]+" ");
                }
                Console.Write("\n");
            }
            Console.ReadKey();
        }
       
    }
}
