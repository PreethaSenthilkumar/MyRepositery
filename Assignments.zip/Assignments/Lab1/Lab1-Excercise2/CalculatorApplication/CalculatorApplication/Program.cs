﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CalcLibrary;

namespace CalculatorApplication
{
    public class Program
    {
        public static void Main(string[] args)
        {
            ArithmeticOperations cal = new ArithmeticOperations();
            Console.WriteLine("What arithmetic operation do you prefer?");
            Console.WriteLine("1.Addition\n 2.Subtraction\n 3.Multiplication 4.Division\n 5.Modulo\n 6.Exit\n");
            int choice = Convert.ToInt32(Console.ReadLine());


                Console.WriteLine("What data-type do youu prefer?");
                string type = Console.ReadLine();
                Console.WriteLine("Enter the numbers");


                if (type == "int")
                {
                    int n1 = Convert.ToInt32(Console.ReadLine());
                    int n2 = Convert.ToInt32(Console.ReadLine());
                    int answer;
                    // double answer2;
                    switch (choice)
                    {
                        case 1:
                            answer = ArithmeticOperations.Add(n1, n2);
                            Console.WriteLine("The sum is : " + answer);
                            break;
                        case 2:
                            answer = cal.Subtract(n1, n2);
                            Console.WriteLine("The subtraction  is : " + answer);
                            break;
                        case 3:
                            answer = ArithmeticOperations.Multiply(n1, n2);
                            Console.WriteLine("The multiplication  is : " + answer);
                            break;
                        case 4:
                            answer = ArithmeticOperations.Divide(n1, n2);
                            Console.WriteLine("The division is : " + answer);
                            break;
                        case 5:
                            answer = ArithmeticOperations.Modulo(n1, n2);
                            Console.WriteLine("The modulo is : " + answer);
                            break;
                    }
 }
                else if (type == "Double")
                {
                    double num1 = Convert.ToDouble(Console.ReadLine());
                    double num2 = Convert.ToDouble(Console.ReadLine());
                    double answer1;

                    switch (choice)
                    {
                        case 1:
                            answer1 = ArithmeticOperations.Add(num1, num2);
                            Console.WriteLine("The modulo is : " + answer1);
                            break;
                        case 2:
                            answer1 = ArithmeticOperations.Subtract(num1, num2);
                            Console.WriteLine("The modulo is : " + answer1);
                            break;
                        case 3:
                            answer1 = ArithmeticOperations.Multiply(num1, num2);
                            Console.WriteLine("The modulo is : " + answer1);
                            break;
                        case 4:
                            answer1 = ArithmeticOperations.Divide(num1, num2);
                            Console.WriteLine("The modulo is : " + answer1);
                            break;
                        case 5:
                            answer1 = ArithmeticOperations.Modulo(num1, num2);
                            Console.WriteLine("The modulo is : " + answer1);
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Data Invalid\n");
                }
               Console.ReadKey();
            }
        }
    }
