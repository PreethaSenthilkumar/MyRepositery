﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwitchConstructApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the data ");
            int value = Convert.ToInt32(Console.ReadLine());

            switch (value)
            {
                case 1:
                        Console.WriteLine("Entered data is accurate");
                    break;
                case 2:
                        Console.WriteLine("Entered data is accurate");
                    break;
                case 3:
                        Console.WriteLine("Entered data is accurate");
                    break;
                case 4:
                        Console.WriteLine("Entered data is accurate");
                    break;
                case 5:

                        Console.WriteLine("Entered data is accurate");
                    break;
              

                default:
                    Console.WriteLine("Irereleavnt Data");
                    break;
            }

            Console.ReadKey();

        }
    }
}
