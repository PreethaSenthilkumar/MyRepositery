﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class Employee
    {
        int emp_id;
        public int EmployeeID
        {
            get { return emp_id; }
            set { emp_id = value; }
        }

        string emp_name;
        public string EmployeeName
        {
            get { return emp_name; }
            set { emp_name = value; }
        }

        string emp_addr;
        public string EmployeeAddr
        {
            get { return emp_addr; }
            set { emp_addr = value; }
        }

        string emp_city;
        public string EmployeeCity
        {
            get { return emp_city; }
            set { emp_city = value; }
        }

        string emp_department;
        public string EmployeeDepartment
        {
            get { return emp_department; }
            set { emp_department = value; }
        }

        double emp_salary;
        public double EmployeeSalary
        {
            get { return emp_salary; }
            set { emp_salary = value; }
        }
    }
}
