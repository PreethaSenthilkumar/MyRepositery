﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLibrary;

namespace EmployeeConsoleApplication
{
    public class Program
    {
        static void Main(string[] args)
        {
           
            Employee[] emp = new Employee[2];

            for (int i = 0; i < emp.Length; i++)
            {
                emp[i] = new Employee();
                Console.WriteLine("Enter EmployeeId : ");
                emp[i].EmployeeID = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter EmployeeName : ");
                emp[i].EmployeeName = Console.ReadLine();

                Console.WriteLine("Enter EmployeeAddress : ");
                emp[i].EmployeeAddr = Console.ReadLine();

                Console.WriteLine("Enter EmployeeCity : ");
                emp[i].EmployeeCity = Console.ReadLine();

                Console.WriteLine("Enter EmployeeDepartment : ");
                emp[i].EmployeeDepartment = Console.ReadLine();

                Console.WriteLine("Enter EmployeeSalary : ");
                emp[i].EmployeeSalary = Convert.ToDouble(Console.ReadLine());
            }

            for(int i=0;i<emp.Length;i++)
            {
                Console.WriteLine("The Employee name is "+emp[i].EmployeeName+" and the salary is "+emp[i].EmployeeSalary);
            }

            Console.ReadKey();
        }
    }
}
