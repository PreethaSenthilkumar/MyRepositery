﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentDemoApplication
{
    class StudentDemo
    {
        int rollno;
        public int RollNumber
        {
            get { return rollno; }
            set { rollno = value; }
        }

        string stdtname;
        public string StudentName
        {
            get { return stdtname; }
            set { stdtname = value; }
        }

        byte age;
        public byte Age
        {
            get { return age; }
            set { age = value; }
        }

        char gender;
        public char Gender
        {
            get { return gender; }
            set { gender = value; }
        }

        DateTime dob;
        public DateTime DateOfBirth
        {
            get { return dob; }
            set { dob = value; }
        }

        string address;
        public string Address
        {
            get { return address; }
            set { address = value; }
        }
        float percent;
        public float Percentage
        {
            get { return percent; }
            set { percent = value; }
        }
    }    
}
