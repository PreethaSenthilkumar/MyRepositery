﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentDemoApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            StudentDemo[] s = new StudentDemo[5];

            for(int i=0;i<s.Length;i++)
            {
                s[i] = new StudentDemo();

                Console.WriteLine("Enter Student RollNumber : ");
                s[i].RollNumber = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Student Name : ");
                s[i].StudentName = Console.ReadLine();

                Console.WriteLine("Enter Student Age : ");
                s[i].Age = Convert.ToByte(Console.ReadLine());

                Console.WriteLine("Enter Student Gender : ");
                s[i].Gender = Convert.ToChar(Console.ReadLine());

                Console.WriteLine("Enter DateOfBirth : ");
                s[i].DateOfBirth = Convert.ToDateTime(Console.ReadLine());

                Console.WriteLine("Enter Student Address : ");
                s[i].Address = Console.ReadLine();

                Console.WriteLine("Enter Student Perentage : ");
                s[i].Percentage = float.Parse(Console.ReadLine());

            }

            for(int i=0;i<s.Length;i++)
            {
                Console.WriteLine("The Student RollNumber is : " + s[i].RollNumber);
                Console.WriteLine("The Student Name is : " + s[i].StudentName);
                Console.WriteLine("The Student Age is : " + s[i].Age);
                Console.WriteLine("The Student Gender is : " + s[i].Gender);
                Console.WriteLine("The Student DOB is : " + s[i].DateOfBirth);
                Console.WriteLine("The Student Address is : " + s[i].Address);
                Console.WriteLine("The Student Percentae is : " + s[i].Percentage);
            }

        }
    }
}
