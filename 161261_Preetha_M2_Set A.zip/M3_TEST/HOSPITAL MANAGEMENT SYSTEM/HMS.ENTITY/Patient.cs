﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS.ENTITY
{
    /// <summary>
    /// Employee ID : 161261
    /// Employee Name : Preetha Senthilkumar
    /// Description : This is entity class for the patient information (ENTITY LIBRARY)
    /// Date of Creation : 17.10.2018
    /// </summary>
    public class Patient
    {
        //Get or set Patient properties
        //Patient_Personal_Info

        public int Patient_Id { get; set; }
        public string Patient_First_Name { get; set; }
        public string Patient_Last_Name { get; set; }
        public string Patient_Gender;
        //public DateTime DOB { get; set; }

        //Patient_Location_Info
        public string Patient_Address { get; set; }
        public string Patient_City { get; set; }
        public string Patient_State{ get; set; }
        public int Patient_PinCode { get; set; }
        public int Patient_PhoneNumber { get; set; }
    }
}
