﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionLibrary
{
    public struct Student
    {
        public int RollNo { get; set; }
        public string Name { get; set; }
    }
}
