﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventDemo2
{
    public class SMSGateway
    {
        public static void SendMessage(string message)
        {
            Console.WriteLine(message);
        }
    }
}
