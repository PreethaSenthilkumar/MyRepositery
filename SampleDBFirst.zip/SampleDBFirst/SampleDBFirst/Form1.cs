﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SampleDBFirst
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ChennaiTraining_21DecEntities entity = new ChennaiTraining_21DecEntities();
            var query = from s in entity.Students
                        select s;
            foreach(Student stu in query )
            {
                listBox1.Items.Add(stu.StudentName + "---" + stu.StudentGrade);

            }

            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            TrainingEntities mycontext = new TrainingEntities();
            var queryCust = from cust in mycontext.Customers
                            select cust;
            foreach(Customer c in queryCust )
            {

                listBox1.Items.Add(c.Name_FirstName);
            }


        }
    }
}
