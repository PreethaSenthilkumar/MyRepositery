﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SampleDBFirst
{
    public partial class AddDetails : Form
    {
        public AddDetails()
        {
            InitializeComponent();
        }
    }
}
